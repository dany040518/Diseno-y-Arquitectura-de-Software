package edu.unisabana.pizzafactory.model;

public abstract class fabricaPizza {
    
   public abstract amasador crearAmasador();
   
   public abstract moldeador crearMoldeador();
   
   public abstract horneador crearHorneador();
   
}
