package edu.unisabana.pizzafactory.model;

public interface horneador {
    void hornear();
}
