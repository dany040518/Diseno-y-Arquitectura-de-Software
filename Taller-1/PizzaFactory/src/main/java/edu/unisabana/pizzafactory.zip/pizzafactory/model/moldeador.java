package edu.unisabana.pizzafactory.model;

public interface moldeador {
    void moldearPizzaPequena();
    void molderarPizzaMediana();
}
