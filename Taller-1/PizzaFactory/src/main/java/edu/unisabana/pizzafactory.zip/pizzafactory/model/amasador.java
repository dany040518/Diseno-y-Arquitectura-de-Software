package edu.unisabana.pizzafactory.model;

public interface amasador {
    void amasar();
}
